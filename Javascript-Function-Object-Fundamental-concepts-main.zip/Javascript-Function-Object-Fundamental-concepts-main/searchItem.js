const lyrics ="Tumi bondu kala paki ami jano ki bosonto kale tomay vulte pari ni ";
const SearchStaring ="paki";
// const lyricsLower =lyrics.toLowerCase();
// const SearchStaringLower=SearchStaring.toLowerCase();
const doesExitOneLine=lyrics.toLowerCase().includes(SearchStaring.toLowerCase());
console.log(doesExitOneLine);

