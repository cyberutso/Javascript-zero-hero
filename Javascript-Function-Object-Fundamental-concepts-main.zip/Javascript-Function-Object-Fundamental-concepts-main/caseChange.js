const username="blackpink";
const userInput ="BlackpInk";
console.log(username.toLowerCase());
console.log(userInput.toLowerCase());
if(username.toLowerCase()===userInput.toLowerCase()){
    console.log("Valid User");
}
else{
    console.log("Invalid User");
    console.log(object);
}