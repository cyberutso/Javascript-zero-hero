function milesToKm(miles){
    const km =miles*1.60;
    return km;

}
const MileTokm =120;
const kilo=milesToKm(MileTokm)
console.log(kilo)
