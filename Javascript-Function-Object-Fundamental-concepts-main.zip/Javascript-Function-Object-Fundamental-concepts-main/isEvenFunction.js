function isEven (number){
    const numberta =number%2;
    if( numberta===0){
        return true;
    }
    else{
        return false;
    }   
    
}
const newItem=isEven(303);
console.log(newItem);