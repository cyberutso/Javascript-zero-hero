function inchTofeet(inch){
    const feet = inch /12;
    return feet;
}
const value=24;
const dadaFeet =inchTofeet(value);
console.log(dadaFeet);