function fact (number){
    let number=1;
    let result=1;
    while(num <= 7){
        result=result*num;
        num++;


    }
    return result;
}