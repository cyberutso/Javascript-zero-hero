function averageMain(class1,class2,class3){
    const total = class1+ class2 + class3
    const average =total/3;
    return average;

}
const class1 = 55;
const class2 = 59;
const class3 = 54;
 
var myAverage =averageMain(class1,class2,class3);
console.log("Our average marks is:",myAverage);
