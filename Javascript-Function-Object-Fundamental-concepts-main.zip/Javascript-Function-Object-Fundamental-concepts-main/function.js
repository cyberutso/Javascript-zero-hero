// target : apply function for basic first code

function bringSingara(){
    console.log("Ami singara khabo");
}
bringSingara();